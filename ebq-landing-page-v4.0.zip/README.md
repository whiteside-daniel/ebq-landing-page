# ebq-landing-page
EBQ Portfolio - Responsive Landing Page Design
Created by: Daniel Whiteside
Created on: 6/29/2021

Known Issues:

    Unable to get shadow element on for the 'complete-department-marketing.png' image
    Alignment of EBQ Logo in iPhone mobile view isn't quite right. The logo is too far to the right. Can't figure out the padding/border settings to fix this
    Some style tags were applied to individual HTML elements instead of using CSS. I could not override the bootstrap CSS defaults in certain cases.
